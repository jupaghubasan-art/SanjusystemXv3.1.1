package com.sanju.systemx

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val red = Color.rgb(255, 28, 55)
    private val bg = Color.rgb(7, 7, 10)
    private val panel = Color.rgb(20, 20, 26)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var shizukuValue: TextView
    private lateinit var gameValue: TextView
    private lateinit var hzValue: TextView
    private lateinit var cpuValue: TextView
    private lateinit var tempValue: TextView
    private lateinit var fpsValue: TextView
    private lateinit var noteValue: TextView
    private var selectedTarget = 90
    private var selectedProfile = "BALANCED"
    private var lastCpuTotal = 0L
    private var lastCpuIdle = 0L
    private var openingStarted = false
    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        refreshShizuku()
        toast(if (result == PackageManagerPermission.GRANTED) "Shizuku permission granted" else "Shizuku permission denied")
    }
    private object PackageManagerPermission { const val GRANTED = 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        Shizuku.addRequestPermissionResultListener(shizukuListener)
        buildUi()
        // System initialization and monitoring begin immediately; the intro never blocks them.
        refreshShizuku()
        refreshDisplay()
        refreshGameStatus()
        tick()
        if (!openingStarted) { openingStarted = true; playIntro() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(16), dp(10), dp(16), dp(10)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("SANJU", 20, red, true)); header.addView(label("SYSTEMX  /  V3", 20, Color.WHITE, true))
        val spacer = View(this); header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        shizukuValue = label("SHIZUKU: CHECKING", 12, red, true); header.addView(shizukuValue)
        root.addView(header)
        root.addView(label("GAME SPACE  •  MLBB: com.mobile.legends", 11, Color.LTGRAY, false).apply { setPadding(0, dp(3), 0, dp(8)) })
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val fpsCard = card("FPS MONITOR")
        fpsValue = label("--", 42, Color.WHITE, true); fpsCard.addView(fpsValue); fpsCard.addView(label("TARGET  $selectedTarget FPS  •  ACTUAL UNAVAILABLE", 11, red, true))
        val statusCard = card("GAME STATUS")
        gameValue = label("CHECKING…", 20, Color.WHITE, true); statusCard.addView(gameValue); statusCard.addView(label("Actual game FPS requires supported device instrumentation.", 11, Color.LTGRAY, false))
        top.addView(fpsCard, LinearLayout.LayoutParams(0, dp(130), 1.2f).apply { rightMargin = dp(8) }); top.addView(statusCard, LinearLayout.LayoutParams(0, dp(130), 1f))
        content.addView(top)
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val displayCard = card("DISPLAY REFRESH")
        hzValue = label("-- Hz", 26, Color.WHITE, true); displayCard.addView(hzValue); displayCard.addView(label("Actual active display mode", 10, Color.LTGRAY, false))
        val cpuCard = card("CPU MONITOR")
        cpuValue = label("--", 26, Color.WHITE, true); cpuCard.addView(cpuValue); cpuCard.addView(label("Usage from /proc/stat", 10, Color.LTGRAY, false))
        val thermalCard = card("TEMPERATURE")
        tempValue = label("UNAVAILABLE", 16, Color.WHITE, true); thermalCard.addView(tempValue); thermalCard.addView(label("Readable thermal sensor only", 10, Color.LTGRAY, false))
        stats.addView(displayCard, LinearLayout.LayoutParams(0, dp(105), 1f).apply { rightMargin = dp(8) }); stats.addView(cpuCard, LinearLayout.LayoutParams(0, dp(105), 1f).apply { rightMargin = dp(8) }); stats.addView(thermalCard, LinearLayout.LayoutParams(0, dp(105), 1f))
        content.addView(stats)
        content.addView(label("PERFORMANCE PROFILE", 12, red, true).apply { setPadding(0, dp(10), 0, dp(5)) })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("DEFAULT", "BALANCED", "PERFORMANCE").forEach { name -> controls.addView(button(name) { selectedProfile = name; noteValue.text = "PROFILE: $name — only supported operations are applied."; if (name == "PERFORMANCE") requestRefreshMode(120) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(6) }) }
        content.addView(controls)
        val targets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(60, 90, 120).forEach { target -> targets.addView(button("$target FPS") { selectedTarget = target; fpsValue.text = "--"; noteValue.text = "TARGET $target FPS selected. Actual FPS is not measurable through a generic public Android API." }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(6) }) }
        content.addView(targets)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("SHIZUKU PERMISSION") { requestShizuku() }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(6) })
        actions.addView(button("USAGE ACCESS") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, LinearLayout.LayoutParams(0, dp(42), 1f))
        content.addView(actions)
        val second = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        second.addView(button("REQUEST 120 HZ") { requestRefreshMode(120) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(6) })
        second.addView(button("GPU / TOUCH CHECK") { runCapabilityCheck() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        content.addView(second)
        noteValue = label("READY • No system changes are claimed unless verified.", 11, Color.LTGRAY, false).apply { setPadding(0, dp(8), 0, 0) }
        content.addView(noteValue)
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
    }

    private fun card(title: String) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(8)); setBackgroundColor(panel); addView(label(title, 11, red, true)) }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    private fun button(text: String, action: () -> Unit) = Button(this).apply { this.text = text; textSize = 10f; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(42, 18, 25))); setOnClickListener { action() } }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun refreshShizuku() {
        val status = try {
            when {
                !Shizuku.pingBinder() -> "DISCONNECTED"
                Shizuku.isPreV11() -> "UNSUPPORTED"
                Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED -> "CONNECTED"
                else -> "PERMISSION REQUIRED"
            }
        } catch (_: Throwable) { "UNSUPPORTED" }
        runOnUiThread { if (::shizukuValue.isInitialized) shizukuValue.text = "SHIZUKU: $status" }
    }
    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) { noteValue.text = "Shizuku service is disconnected. Start Shizuku first."; return }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) { toast("Shizuku connected and permitted"); refreshShizuku() }
            else Shizuku.requestPermission(1001)
        } catch (t: Throwable) { noteValue.text = "SHIZUKU UNSUPPORTED: ${t.javaClass.simpleName}" }
    }
    private fun refreshDisplay() {
        try {
            val display = if (android.os.Build.VERSION.SDK_INT >= 30) display else @Suppress("DEPRECATION") windowManager.defaultDisplay
            val rate = display?.refreshRate ?: 0f
            hzValue.text = if (rate > 0) String.format(Locale.US, "%.0f Hz", rate) else "UNAVAILABLE"
        } catch (_: Throwable) { hzValue.text = "UNAVAILABLE" }
    }
    private fun requestRefreshMode(target: Int) {
        try {
            val d = if (android.os.Build.VERSION.SDK_INT >= 30) display else @Suppress("DEPRECATION") windowManager.defaultDisplay
            val modes = d?.supportedModes ?: emptyArray()
            val mode = modes.filter { it.refreshRate <= target + 0.5f }.maxByOrNull { it.refreshRate }
                ?: modes.maxByOrNull { it.refreshRate }
            if (mode == null) { noteValue.text = "REFRESH RATE UNSUPPORTED: no display modes exposed."; return }
            val params = window.attributes
            params.preferredDisplayModeId = mode.modeId
            window.attributes = params
            window.decorView.postDelayed({ refreshDisplay(); val actual = d.refreshRate; noteValue.text = "REQUESTED: ${target} Hz • ACTUAL: ${"%.0f".format(Locale.US, actual)} Hz • App-window request; device policy may override." }, 500)
        } catch (t: Throwable) { noteValue.text = "REFRESH RATE NOT APPLIED: ${t.javaClass.simpleName}" }
    }
    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return try { ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED } catch (_: Throwable) { false }
    }
    private fun refreshGameStatus() {
        if (!hasUsageAccess()) { gameValue.text = "USAGE ACCESS NEEDED"; return }
        try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val events = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 60_000, now)
            val latest = events.maxByOrNull { it.lastTimeUsed }
            val running = latest?.packageName == "com.mobile.legends" && now - latest.lastTimeUsed < 20_000
            gameValue.text = if (running) "MLBB DETECTED" else "MLBB NOT DETECTED"
            if (running) noteValue.text = "MLBB detected by Usage Access. Profile: $selectedProfile; target: $selectedTarget FPS. Hardware controls remain capability-dependent."
        } catch (_: Throwable) { gameValue.text = "DETECTION UNAVAILABLE" }
    }
    private fun readCpu(): String {
        return try {
            val parts = java.io.File("/proc/stat").bufferedReader().use { it.readLine().trim().split(Regex("\\s+")) }
            val values = parts.drop(1).take(8).map { it.toLong() }
            val idle = values[3] + (values.getOrNull(4) ?: 0L)
            val total = values.sum()
            val deltaTotal = total - lastCpuTotal; val deltaIdle = idle - lastCpuIdle
            lastCpuTotal = total; lastCpuIdle = idle
            if (deltaTotal <= 0) "CPU --" else "CPU ${(((deltaTotal - deltaIdle) * 100) / deltaTotal).coerceIn(0,100)}%"
        } catch (_: Throwable) { "CPU UNSUPPORTED" }
    }
    private fun readTemperature(): String {
        return try {
            val thermal = getSystemService(Context.THERMAL_SERVICE) as android.os.PowerManager
            // Android does not provide a general public CPU-temperature getter; avoid guessing.
            "UNAVAILABLE"
        } catch (_: Throwable) { "UNAVAILABLE" }
    }
    private fun tick() {
        thread(name = "SanjuMonitor") {
            val cpu = readCpu()
            runOnUiThread {
                if (::cpuValue.isInitialized) cpuValue.text = cpu
                if (::tempValue.isInitialized) tempValue.text = "UNAVAILABLE"
                refreshDisplay(); refreshGameStatus(); refreshShizuku()
            }
        }
        handler.postDelayed({ tick() }, 2000)
    }
    private fun runCapabilityCheck() {
        thread {
            val result = try {
                val shizukuOk = Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (!shizukuOk) "GPU CLOCK: SHIZUKU REQUIRED OR UNSUPPORTED • TOUCH RATE: DEVICE CONTROL UNSUPPORTED • GPU UTILIZATION: NOT EXPOSED BY GENERIC API"
                else {
                    val out = shell("for f in /sys/class/kgsl/kgsl-3d0/gpuclk /sys/class/devfreq/*gpu*/cur_freq /sys/class/devfreq/*mali*/cur_freq; do [ -r \"$f\" ] && echo \"$f: $(cat \"$f\")\"; done; echo CAPABILITY_CHECK_COMPLETE")
                    if (out.contains("CAPABILITY_CHECK_COMPLETE") && out.lines().none { it.contains(":") }) "GPU CLOCK CONTROL: UNSUPPORTED ON THIS DEVICE • TOUCH RATE: UNSUPPORTED" else "GPU INTERFACE FOUND (READ-ONLY CHECK): $out • WRITE CONTROL NOT ATTEMPTED"
                }
            } catch (_: Throwable) { "GPU CLOCK: UNSUPPORTED • TOUCH RATE: UNSUPPORTED" }
            runOnUiThread { noteValue.text = result }
        }
    }
    private fun shell(command: String): String {
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val output = BufferedReader(InputStreamReader(process.inputStream)).readText()
        process.waitFor()
        return output.take(500)
    }
    private fun playIntro() {
        val overlay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK) }
        val logo = TextView(this).apply { text = "◉"; textSize = 70f; gravity = Gravity.CENTER; setTextColor(red); typeface = Typeface.DEFAULT_BOLD }
        val brand = label("SANJUSYSTEMX", 24, Color.WHITE, true).apply { gravity = Gravity.CENTER; alpha = 0f }
        val ready = label("GAME SPACE READY", 12, red, true).apply { gravity = Gravity.CENTER; alpha = 0f }
        overlay.addView(logo); overlay.addView(brand); overlay.addView(ready); addContentView(overlay, android.view.ViewGroup.LayoutParams(-1, -1))
        logo.scaleX = .4f; logo.scaleY = .4f; logo.alpha = 0f
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(900).start()
        handler.postDelayed({ logo.animate().scaleX(1.15f).scaleY(1.15f).setDuration(350).start(); brand.animate().alpha(1f).setDuration(450).start() }, 1700)
        handler.postDelayed({ ready.animate().alpha(1f).setDuration(350).start() }, 3300)
        handler.postDelayed({ overlay.animate().alpha(0f).setDuration(300).withEndAction { (overlay.parent as? android.view.ViewGroup)?.removeView(overlay) }.start() }, 5000)
    }
    override fun onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {} }
}
