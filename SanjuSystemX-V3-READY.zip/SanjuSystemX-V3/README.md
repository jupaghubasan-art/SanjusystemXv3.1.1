# SanjuSystemX V3

A Kotlin Android project for the SanjuSystemX Game Space dashboard.

- Application ID: `com.sanju.systemx`
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- Compile SDK: 35
- Minimum Android version: 8.0 (API 26)

## Build APK on GitHub

1. Upload the **contents** of this folder to the root of your GitHub repository. Do not upload the ZIP itself as a single file.
2. Ensure `.github/workflows/build.yml` is included. On GitHub mobile, hidden folders can be awkward to upload; use the repository's **Add file** workflow or upload from a desktop browser if necessary.
3. Push to `main` or `master`, or open **Actions → Build SanjuSystemX APK → Run workflow**.
4. Open the completed run and download the `SanjuSystemX-V3-debug-apk` artifact.

The workflow installs JDK 17, Android SDK tooling, and Gradle 8.9, then runs `assembleDebug`. A Gradle wrapper is not required by this workflow.

## Device setup

1. Install and start the official Shizuku app/service.
2. Open SanjuSystemX and request Shizuku permission.
3. Grant Usage Access in Android Settings for Mobile Legends foreground detection.

## Honest device limitations

- Display refresh rate shown is read from Android. A preferred display mode request applies to this app's window and may be overridden by OEM policy or the game.
- FPS target selection is only a target. This project does not measure actual MLBB render FPS through a universal public API.
- CPU usage is estimated from `/proc/stat` when readable.
- GPU utilization, GPU frequency control, CPU/GPU temperatures, and touch sampling controls vary by device and are not claimed applied unless a supported interface is verified.
- The project does not write to arbitrary sysfs paths or claim a GPU boost when unsupported.
- It does not make device-wide settings changes, so there is no device-wide setting to restore in this version.
